// battlefield.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "firstgame.h"
#include "battlefield.h"
#include "afxdialogex.h"
#include "signal.h"

CfirstgameApp *p2;

// battlefield �Ի���

IMPLEMENT_DYNAMIC(battlefield, CDialogEx)

battlefield::battlefield(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, str_1(_T(""))
	, str_2(_T(""))
	, str_3(_T(""))
	, str_4(_T(""))
{

}

battlefield::~battlefield()
{
}

void battlefield::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, e_1);
	DDX_Control(pDX, IDC_EDIT2, e_2);
	DDX_Control(pDX, IDC_EDIT3, e_3);
	DDX_Control(pDX, IDC_EDIT4, e_4);
	DDX_Control(pDX, IDC_STATIC1, s_1);
	DDX_Control(pDX, IDC_STATIC2, s_2);
	DDX_Control(pDX, IDC_STATIC3, s_3);
	DDX_Control(pDX, IDC_STATIC4, s_4);
	DDX_Text(pDX, IDC_EDIT1, str_1);
	DDX_Text(pDX, IDC_EDIT2, str_2);
	DDX_Text(pDX, IDC_EDIT3, str_3);
	DDX_Text(pDX, IDC_EDIT4, str_4);
}


BEGIN_MESSAGE_MAP(battlefield, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON2, &battlefield::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON1, &battlefield::OnBnClickedButton1)
	ON_WM_CHANGEUISTATE()
END_MESSAGE_MAP()


// battlefield ��Ϣ��������
BOOL battlefield::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	p2 = (CfirstgameApp *)AfxGetApp();

	if (p2->choice == 0) { s_2.ShowWindow(false); e_2.ShowWindow(false); s_3.ShowWindow(false); e_3.ShowWindow(false); s_4.ShowWindow(false); e_4.ShowWindow(false); }
	else if (p2->choice == 1) { s_1.ShowWindow(false); e_1.ShowWindow(false); s_4.ShowWindow(false); e_4.ShowWindow(false); }
	else if (p2->choice == 2) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 3) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 4) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 5) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	//switch (p2->choice) {
	//case 0: s_2.ShowWindow(false), e_2.ShowWindow(false), s_3.ShowWindow(false), e_3.ShowWindow(false), s_4.ShowWindow(false), e_4.ShowWindow(false);
	//case 1: s_1.ShowWindow(false), e_1.ShowWindow(false), s_4.ShowWindow(false), e_4.ShowWindow(false);
	//case 2: s_1.ShowWindow(false), e_1.ShowWindow(false);
	//case 3: s_1.ShowWindow(false), e_1.ShowWindow(false);
	//case 4: s_1.ShowWindow(false), e_1.ShowWindow(false);
	//case 5: s_1.ShowWindow(false), e_1.ShowWindow(false);
	//}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void battlefield::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	OnClose();
	OnCancel();
	PostNcDestroy();
}

void battlefield::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	OnClose();
	OnCancel();
	PostNcDestroy();

	signal s;
	s.DoModal();
}







