#include "CRecordEntity.h"


CRecordEntity::CRecordEntity(int id) :
	m_id(id)
{
}


CRecordEntity::~CRecordEntity(void)
{
}