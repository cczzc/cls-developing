#include "CFieldEntity.h"


CFieldEntity::CFieldEntity(int id, CString name, int type, int length, int isPK, int isNull, int isUnique, CString comment) :
	m_id(id),
	m_sName(name),
	m_iType(type),
	m_iLength(length),
	m_isPK(isPK),
	m_isNull(isNull),
	m_isUnique(isUnique),
	m_sComment(comment)
{
	

}

CFieldEntity::CFieldEntity(CString &str)
{
	

}

CFieldEntity::~CFieldEntity(void)
{
}

