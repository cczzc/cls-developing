
#include "CDBEntity.h"


CDBEntity::CDBEntity(int id, CString name, int type, int tableNum) :
	m_id(id), m_sName(name), m_iType(type), m_iTableNum(tableNum)
{
	
}


CDBEntity::CDBEntity(CString &str)
{
	
}

CDBEntity::~CDBEntity(void)
{
}
