// battlefield.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "firstgame.h"
#include "firstgameDlg.h"
#include "battlefield.h"
#include "afxdialogex.h"
#include "signal.h"
#include "string.h"
#include<string> 
#include <fstream>
#include <iostream>
using namespace std;

CfirstgameApp *p2;

void battlefield::writetree() {

	FILE *inFile;
	fopen_s(&inFile, "���ݿ�\\tree", "r");
	CStdioFile cfile(inFile);
	CString a;
	int n = 0;
	CString *c = new CString[n], *d = new CString[n];

	while (!feof(inFile)) {

		cfile.ReadString(a);

		n++;

		if (n % 2 == 1) {

			c = new CString[n];

			for (int i = 0; i < n - 1; i++) {
				c[i] = d[i];
			}
			c[n - 1] = a;

			delete[]d;
		}
		else {

			d = new CString[n];

			for (int i = 0; i < n - 1; i++) {
				d[i] = c[i];
			}
			d[n - 1] = a;

			delete[]c;
		}
	}

	fclose(inFile);

	CString ctr;
	fstream inStream;

	inStream.open("���ݿ�\\tree", ios::out);

	if (n % 2 == 1) {

		for (int i = 0; i < n; i++) {

			if (p2->choice == 1) {
				for (int j = 0; j < c[i].GetLength(); j++)
				{

					if (c[i].GetAt(j) == p2->signalcontent) {

						if (p2->currentdatabase == c[i].Left(j)) {

							c[i] = c[i] + str_2 + _T("#");
						}

						break;
					}
				}
			}
			inStream << CT2A(c[i]) << "\n";
		}

		delete[]c;
	}
	else {

		for (int i = 0; i < n; i++) {
			if (p2->choice == 1) {
				for (int j = 0; j < d[i].GetLength(); j++)
				{

					if (d[i].GetAt(j) == p2->signalcontent) {

						if (p2->currentdatabase == d[i].Left(j)) {

							d[i] = d[i] + str_2 + _T("#");
						}

						break;
					}
				}
			}
			inStream << CT2A(d[i]) << "\n";
		}
		delete[]d;
	}

	if (p2->choice == 0) {

		inStream << CT2A(str_1) << "#\n";
	}
	inStream.close();
}

BOOL battlefield::deletetable() {

	UpdateData();

	FILE *inFile;
	fopen_s(&inFile, "���ݿ�\\tree", "r");
	CStdioFile cfile(inFile);
	CString a, b;
	BOOL seldatabase = false;
	BOOL seltable = false;

	while (!feof(inFile)) {

		cfile.ReadString(a);

		int num = 0;
		int last = 0;
		int next = 0;

		for (int i = 0; i < a.GetLength(); i++)
		{

			if (a.GetAt(i) == p2->signalcontent) {

				next = i;
				if (num == 0) {

					if (p2->currentdatabase == a.Left(next)) {

						seldatabase = true;
					}
				}
				else {

					if (seldatabase) {

						b = a.Right(a.GetLength() - last - 1);
						if (str_2 == b.Left(next - last - 1)) {

							seltable = true;
						}
					}
				}

				num++;
				last = next;
			}
		}

		seldatabase = false;

		if (seltable) {

			break;
		}
	}

	fclose(inFile);

	if (!seltable) {

		return false;
	}
	else {


	}
}

BOOL battlefield::createtable() {

	UpdateData();

	FILE *inFile;
	fopen_s(&inFile, "���ݿ�\\tree", "r");
	CStdioFile cfile(inFile);
	CString a, b;
	BOOL seldatabase = false;
	BOOL seltable = false;

	while (!feof(inFile)) {

		cfile.ReadString(a);

		int num = 0;
		int last = 0;
		int next = 0;

		for (int i = 0; i < a.GetLength(); i++)
		{

			if (a.GetAt(i) == p2->signalcontent) {

				next = i;
				if (num == 0) {

					if (p2->currentdatabase == a.Left(next)) {

						seldatabase = true;
					}
				}
				else {

					if (seldatabase) {

						b = a.Right(a.GetLength() - last - 1);
						if (str_2 == b.Left(next - last - 1)) {

							seltable = true;
						}
					}
				}

				num++;
				last = next;
			}
		}

		seldatabase = false;

		if (seltable) {

			break;
		}
	}

	fclose(inFile);

	if (seltable) {

		return false;
	} else {

		CString catalog("���ݿ�\\");
		CString c("\\");

		p2->currenttable = str_2;

		catalog = catalog + p2->currentdatabase + c + p2->currenttable;

		fstream inStream;
		inStream.open(catalog,ios::out);

		int num = 0;
		int last = 0;
		int next = 0;
		string str = "1234";

		for (int i = 0; i < str_3.GetLength(); i++) {

			if (str_3.GetAt(i) == p2->signaldivision) {

			    next = i;
			    if (num == 0) {

			        str = CT2A(str_3.Left(next));
			        inStream << str << "#\n";
			    }
			    else {

			        b = str_3.Right(str_3.GetLength() - last - 1);
			        str = CT2A(b.Left(next - last - 1));;
			        inStream << str << "#\n";
			    }

			    num++;
			    last = next;
			}
		}
		
		inStream.close();

		return true;
	}

	return false;
}

void battlefield::change() {

	if (p2->choice == 0) {
		CString DBname;
	CString m_strFolderPath = _T("���ݿ�//");
	
	UpdateData(TRUE);
	GetDlgItem(IDC_EDIT1)->GetWindowText(DBname);
	m_strFolderPath = m_strFolderPath + DBname;

	createDB db;
	try
	{
		db.create(m_strFolderPath);
		writetree();
	}
	catch(ExistException *e)
	{
		AfxMessageBox(e->toString());
	}
	}
	else if (p2->choice == 1) { 

		if (createtable()) {

			p2->operation = 1;

			writetree();

		} else {
			p2->operation = 8;
		}
	}
	else if (p2->choice == 3)
	{
		CString tbname;
		CString strDBPath = _T("���ݿ�\\db\\");
		UpdateData(TRUE);
		GetDlgItem(IDC_EDIT2)->GetWindowText(tbname);
		strDBPath = strDBPath + tbname;

		if (!PathFileExists(strDBPath))
		{
			AfxMessageBox(_T("�ñ�������"));
		}

		CString str;
		CString sstr;
		CString strFile;
		CString strAry;

		char* cstrFile;
		int i = 0, j = 0;

		char*delim = ";";
		char* strary = NULL;
		char* stra = NULL;
		if (PathFileExists(strDBPath))
		{
			GetDlgItem(IDC_EDIT4)->GetWindowText(strAry);
			
			int len = WideCharToMultiByte(CP_ACP, 0, strAry, -1, NULL, 0, NULL, NULL);
			strary = new char[len + 1];
			WideCharToMultiByte(CP_ACP, 0, strAry, -1, strary, len, NULL, NULL);
			//��CStringת��Ϊchar*

			stra = strtok(strary, delim);//�ָ��ַ���
			//sstr.Format("%s", strtok(strary, delim));
			CStdioFile fFile(strDBPath, CFile::modeRead, NULL);



			while (fFile.ReadString(strFile))
			{
				i++;
				CString s(stra);
				str = str + strFile + s + _T("#") + _T("\r\n");
				if (stra = strtok(NULL, delim))
				{
					j++;
				}
				//stra = strtok(NULL, delim);
			}
			strFile.ReleaseBuffer();
			fFile.Close();
			if (i == j + 1)
			{
				CFile WriteFile;
				WriteFile.Open(strDBPath, CFile::modeWrite | CFile::modeRead | CFile::modeCreate);

				int len = WideCharToMultiByte(CP_ACP, 0, str, -1, NULL, 0, NULL, NULL);
				char *WriteBuf  = new char[len + 1];
				WideCharToMultiByte(CP_ACP, 0, str, -1, WriteBuf, len, NULL, NULL);

				//char *WriteBuf = (LPSTR)(LPCSTR)str;
				WriteFile.Write(WriteBuf, strlen(WriteBuf) + 1);
				AfxMessageBox(_T("�ɹ���������"));
			}
			else
			{
				AfxMessageBox(_T("�����������"));
			}
		}
	}
}

// battlefield �Ի���

IMPLEMENT_DYNAMIC(battlefield, CDialogEx)

battlefield::battlefield(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, str_1(_T(""))
	, str_2(_T(""))
	, str_3(_T(""))
	, str_4(_T(""))
{

}

battlefield::~battlefield()
{
}

void battlefield::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, e_1);
	DDX_Control(pDX, IDC_EDIT2, e_2);
	DDX_Control(pDX, IDC_EDIT3, e_3);
	DDX_Control(pDX, IDC_EDIT4, e_4);
	DDX_Control(pDX, IDC_STATIC1, s_1);
	DDX_Control(pDX, IDC_STATIC2, s_2);
	DDX_Control(pDX, IDC_STATIC3, s_3);
	DDX_Control(pDX, IDC_STATIC4, s_4);
	DDX_Text(pDX, IDC_EDIT1, str_1);
	DDX_Text(pDX, IDC_EDIT2, str_2);
	DDX_Text(pDX, IDC_EDIT3, str_3);
	DDX_Text(pDX, IDC_EDIT4, str_4);
}


BEGIN_MESSAGE_MAP(battlefield, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON2, &battlefield::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON1, &battlefield::OnBnClickedButton1)
	ON_WM_CHANGEUISTATE()
	ON_EN_CHANGE(IDC_EDIT1, &battlefield::OnEnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT4, &battlefield::OnEnChangeEdit4)
END_MESSAGE_MAP()


// battlefield ��Ϣ��������
BOOL battlefield::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	p2 = (CfirstgameApp *)AfxGetApp();

	if (p2->choice == 0) { s_2.ShowWindow(false); e_2.ShowWindow(false); s_3.ShowWindow(false); e_3.ShowWindow(false); s_4.ShowWindow(false); e_4.ShowWindow(false); }
	else if (p2->choice == 1) { s_1.ShowWindow(false); e_1.ShowWindow(false); s_4.ShowWindow(false); e_4.ShowWindow(false); }
	else if (p2->choice == 2) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 3) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 4) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 5) { s_1.ShowWindow(false); e_1.ShowWindow(false); }
	else if (p2->choice == 6) { s_1.ShowWindow(false); e_1.ShowWindow(false); s_3.ShowWindow(false); e_3.ShowWindow(false); s_4.ShowWindow(false); e_4.ShowWindow(false);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void battlefield::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	OnClose();
	OnCancel();
	PostNcDestroy();
}

void battlefield::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	OnClose();
	OnCancel();
	PostNcDestroy();

	change();

	signal s;
	s.DoModal();
}









void battlefield::OnEnChangeEdit1()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialogEx::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
}


void battlefield::OnEnChangeEdit4()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialogEx::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
}
